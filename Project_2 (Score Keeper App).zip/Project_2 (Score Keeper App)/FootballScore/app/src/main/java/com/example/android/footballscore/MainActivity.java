package com.example.android.footballscore;

        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.view.View;
        import android.widget.TextView;

        import com.example.android.footballscore.R;

public class MainActivity extends AppCompatActivity {
    int scoreTeamA = 0;
    int scoreTeamB = 0;
    int touchDownA = 0;
    int touchDownB = 0;
    int fieldGoalA = 0;
    int fieldGoalB = 0;
    int conversionA = 0;
    int conversionB = 0;
    int safetyA = 0;
    int safetyB = 0;
    int extraA = 0;
    int extraB = 0;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void resetPoints (View v) {
        scoreTeamA = 0;
        scoreTeamB = 0;
        touchDownA = 0;
        touchDownB = 0;
        fieldGoalA = 0;
        fieldGoalB = 0;
        conversionA = 0;
        conversionB = 0;
        safetyA = 0;
        safetyB = 0;
        extraA = 0;
        extraB = 0;

        displayForTeamA(scoreTeamA);
        displayForTeamB(scoreTeamB);
        displayTDownA(touchDownA);
        displayTDownB(touchDownB);
        displayFGoalA(fieldGoalA);
        displayFGoalB(fieldGoalB);
        displayConvA(conversionA);
        displayConvB(conversionB);
        displaySafetyA(safetyA);
        displaySafetyB(safetyB);
        displayExtraA(extraA);
        displayExtraB(extraB); }
    /**

     * Displays the given score for Team A.

     */
    public void xtraA (View v) {
        scoreTeamA = scoreTeamA + 1;
        extraA = extraA + 1;
        displayForTeamA(scoreTeamA);
        displayExtraA(extraA);  }

    public void convA (View v) {
        scoreTeamA = scoreTeamA + 2;
        conversionA = conversionA + 2;
        displayForTeamA(scoreTeamA);
        displayConvA(conversionA);  }

    public void sftyA (View v) {
        scoreTeamA = scoreTeamA + 2;
        safetyA = safetyA + 2;
        displayForTeamA(scoreTeamA);
        displaySafetyA(safetyA); }

    public void fdglA (View v) {
        scoreTeamA = scoreTeamA + 3;
        fieldGoalA = fieldGoalA + 3;
        displayForTeamA(scoreTeamA);
        displayFGoalA(fieldGoalA);}

    public void tcdnA (View v) {
        scoreTeamA = scoreTeamA + 6;
        touchDownA = touchDownA + 6;
        displayForTeamA(scoreTeamA);
        displayTDownA(touchDownA);}


    public void displayForTeamA(int score) {

        TextView scoreView = findViewById(R.id.team_a_score);

        scoreView.setText(String.valueOf(score)); }


    public void displayTDownA(int score) {

        TextView scoreView = findViewById(R.id.touch_down_a);

        scoreView.setText(String.valueOf(score)); }


    public void displayFGoalA(int score) {

        TextView scoreView = findViewById(R.id.field_goal_a);

        scoreView.setText(String.valueOf(score)); }


    public void displayConvA(int score) {

        TextView scoreView = findViewById(R.id.conversion_a);

        scoreView.setText(String.valueOf(score)); }

    public void displaySafetyA(int score) {

        TextView scoreView = findViewById(R.id.safety_a);

        scoreView.setText(String.valueOf(score)); }


    public void displayExtraA(int score) {

        TextView scoreView = findViewById(R.id.extra_point_a);

        scoreView.setText(String.valueOf(score)); }

    /**
     * Displays the given score for Team B.
     */
    public void xtraB (View v){
        scoreTeamB = scoreTeamB + 1;
        extraB = extraB +1;
        displayForTeamB(scoreTeamB);
        displayExtraB(extraB);
    }

    public void convB (View v) {
        scoreTeamB = scoreTeamB + 2;
        conversionB = conversionB + 2;
        displayForTeamB(scoreTeamB);
        displayConvB(conversionB);
    }
    public void sftyB (View v) {
        scoreTeamB = scoreTeamB + 2;
        safetyB = safetyB + 2;
        displayForTeamB(scoreTeamB);
        displaySafetyB(safetyB);
    }

    public void fdglB (View v) {
        scoreTeamB = scoreTeamB + 3;
        fieldGoalB = fieldGoalB + 3;
        displayForTeamB(scoreTeamB);
        displayFGoalB(fieldGoalB);}

public void tcdnB (View v) {
        scoreTeamB = scoreTeamB + 6;
        touchDownB = touchDownB + 6;
        displayForTeamB(scoreTeamB);
        displayTDownB(touchDownB);}

    public void displayForTeamB(int score) {
        TextView scoreView = findViewById(R.id.team_b_score);
        scoreView.setText(String.valueOf(score));
    }

    public void displayTDownB(int score) {

        TextView scoreView = findViewById(R.id.touch_down_b);

        scoreView.setText(String.valueOf(score)); }


    public void displayFGoalB(int score) {

        TextView scoreView = findViewById(R.id.field_goal_b);

        scoreView.setText(String.valueOf(score)); }


    public void displayConvB(int score) {

        TextView scoreView = findViewById(R.id.conversion_b);

        scoreView.setText(String.valueOf(score)); }

    public void displaySafetyB(int score) {

        TextView scoreView = findViewById(R.id.safety_b);

        scoreView.setText(String.valueOf(score)); }

    public void displayExtraB(int score) {

        TextView scoreView = findViewById(R.id.extra_point_b);

        scoreView.setText(String.valueOf(score)); }


}
